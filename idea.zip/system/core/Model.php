<?php
namespace Oishy\Core;

/**
* Base Model
*
* This class does nothing. Unless you want it to do something!
*/
class Model
{

}
