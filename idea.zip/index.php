<?php

/**
 * Oishy - The Divine Atomic PHP Framework!
 *
 * @author Miraz Mac <mirazmac@gmail.com>
 * @version 0.1
 * @since 0.1
 *
 * @todo Implement tests
 * @todo Add more detailed code comments to improve readability
 */

require __DIR__ . '/oishy-config.php';

/**
 * Boot the system watson!
 *
 * Well, that was fast!
 */
require SYSTEM . 'boot.php';
