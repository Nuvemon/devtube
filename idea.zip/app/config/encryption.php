<?php
/**
 * Encryption Configuration
 *
 * @since 0.1
 */

return [
    /**
     * Encryption key to use for encryption/decryption
     *
     * @var string
     */
    'key' => '|lN2#E9]/^?Ste,{1x7n[4L@WE}`Bd',

    /**
     * HMAC Salt for encryption
     */
    'hmac_salt' => '#4tTIF?2MTR^Vr-:6tLS"{_%!*9186'
    ];
