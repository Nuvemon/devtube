<?php
/**
 * Database Configuration
 *
 * @since 0.1
 */

return [

    'dsn' => 'mysql:host=devtube.cloudon.live; dbname=homefa89_tube; charset=utf8mb4',

    /**
     * Database username
     *
     * @var string
     */
    'username' => 'homefa89_devtube',

    /**
     * Database user password
     *
     * @var string
     */
    'password' => 'sofia2636',

    /**
     * Set PDO Fetch mode
     *
     * @var  mixed
     */
    'fetch_mode' => \PDO::FETCH_ASSOC,

    /**
     * Set PDO Error Mode
     *
     * @var mixed
     */
    'err_mode' => \PDO::ERRMODE_EXCEPTION
    ];
